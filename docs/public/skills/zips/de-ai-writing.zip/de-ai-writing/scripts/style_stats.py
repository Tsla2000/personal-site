#!/usr/bin/env python3
"""中文写作风格统计（仅标准库）。用法: style_stats.py file1.md [file2 ...] [--json]
无参数时读 stdin。统计均为真实计算，供风格档案引用。"""
import sys, re, json, statistics

PARTICLES = ["的","了","呢","吧","啊","嘛","呀","哈","啦","哦","呗","咯","嘿嘿","哈哈"]
SECOND = ["你们","朋友们","您","你"]

def strip_md(t):
    t = re.sub(r"```.*?```", "", t, flags=re.S)
    t = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", t)
    t = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", t)
    t = re.sub(r"^\s{0,3}(#{1,6}|>|[-*+]|\d+[.)])\s*", "", t, flags=re.M)
    t = re.sub(r"[*_`]", "", t)
    return t

def han_count(s): return len(re.findall(r"[\u4e00-\u9fff]", s))
def body_len(s): return len(re.sub(r"\s", "", s))

def pct(xs, p):
    if not xs: return 0
    xs = sorted(xs); k = (len(xs)-1)*p/100; f = int(k); c = min(f+1, len(xs)-1)
    return xs[f] + (xs[c]-xs[f])*(k-f)

def summ(xs):
    if not xs: return {"n":0,"mean":0,"median":0,"p90":0}
    return {"n":len(xs),"mean":round(statistics.mean(xs),1),"median":statistics.median(xs),"p90":round(pct(xs,90),1)}

def analyze(text):
    t = strip_md(text)
    chars = body_len(t); per_k = lambda n: round(n*1000/chars, 2) if chars else 0
    paras = [p.strip() for p in re.split(r"\n\s*\n|\n", t) if p.strip()]
    sents = [s for s in re.split(r"[。！？!?…]+|\n", t) if body_len(s)]
    units = [s for s in re.split(r"[，,；;。！？!?…：:\n]+", t) if body_len(s)]
    sent_per_para = [max(1, len([s for s in re.split(r"[。！？!?…]+", p) if body_len(s)])) for p in paras]
    np_ = len(paras) or 1
    dist = {"单句成段": sum(1 for n in sent_per_para if n==1),
            "2-3句": sum(1 for n in sent_per_para if 2<=n<=3),
            "4句以上": sum(1 for n in sent_per_para if n>=4)}
    # 粒子：先数长词再数单字，避免"哈哈"重复计数
    tmp, part = t, {}
    for w in sorted(PARTICLES, key=len, reverse=True):
        c = tmp.count(w); part[w] = {"count":c, "per_1k":per_k(c)}; tmp = tmp.replace(w, " ")
    tmp2, sec = t, 0
    for w in SECOND: sec += tmp2.count(w); tmp2 = tmp2.replace(w, " ")
    wo = t.count("我")
    punct = {"破折号——": t.count("——") + len(re.findall(r"(?<!—)—(?!—)", t)),
             "冒号": t.count("：") + len(re.findall(r"(?<=[\u4e00-\u9fff]):", t)),
             "顿号、": t.count("、")}
    return {
      "字符数(去空白)": chars, "汉字数": han_count(t),
      "句长(句号/问叹号切分,字)": summ([body_len(s) for s in sents]),
      "短单位长(逗号等切分,字)": summ([body_len(u) for u in units]),
      "段落数": len(paras), "段长(字)": summ([body_len(p) for p in paras]),
      "段落句数分布": {k: f"{v} ({round(v*100/np_,1)}%)" for k,v in dist.items()},
      "助词每千字": {k:v for k,v in sorted(part.items(), key=lambda kv:-kv[1]["count"]) if v["count"]},
      "我:你": {"我":wo, "你类":sec, "比值": f"{wo}:{sec}" + (f" ≈ {round(wo/sec,2)}:1" if sec else "")},
      "标点每千字": {k:{"count":v,"per_1k":per_k(v)} for k,v in punct.items()},
    }

def main():
    args = [a for a in sys.argv[1:] if a != "--json"]
    texts = [(a, open(a, encoding="utf-8").read()) for a in args] or [("stdin", sys.stdin.read())]
    out = {name: analyze(tx) for name, tx in texts}
    if len(texts) > 1: out["__合计__"] = analyze("\n\n".join(tx for _, tx in texts))
    if "--json" in sys.argv: print(json.dumps(out, ensure_ascii=False, indent=2)); return
    for name, r in out.items():
        print(f"## {name}")
        for k, v in r.items(): print(f"- {k}: {json.dumps(v, ensure_ascii=False) if isinstance(v, dict) else v}")
        print()
if __name__ == "__main__": main()

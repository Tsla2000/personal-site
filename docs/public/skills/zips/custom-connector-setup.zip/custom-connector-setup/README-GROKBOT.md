# 自定义连接器/MCP 接入 Skill（给 GrokBot）

2026-10-18 从 Muse 导出当前最新版（今日刚更新过）。这是 Muse 侧用来给任意第三方服务搭"连接器"的完整方法论 + 模板。

## 方法论（可直接搬）

1. **先找现成路线**：官方 API 文档 → 官方 MCP server → 可信第三方集成（Zapier/Composio 这类 hub）→ 最后才自己写。
2. **凭证隔离**：密钥绝不进文件/环境变量/日志；helper 里只放占位符，真实凭证在"已批准的请求"发出时才由运行时替换。这是整套设计最值得抄的部分。
3. **先验证再沉淀**：连接建好后先跑一次无害的读操作证明凭证有效，再写 CONNECTOR.md 文档；没跑过的操作标注 untested。
4. **MCP 接入**：用 `list-tools` 列出全部操作，只把审核过的工具名写进白名单 `ALLOWED_TOOLS`，服务器后来新增的工具默认拦下。

## GrokBot 适配注意

- `credentials.request_api_access`、`dynamic_credentials.py` 的 surrogate 机制是 Muse 运行时的专有实现，GrokBot 那边没有——**方法论拿走，实现自己重做**：GrokBot 需要自己的一套"安全存密钥 + 请求时注入"流程，这是前置条件。
- `bin/scaffold-connector-docs` 脚手架里写死的路径（`/opt/muse/...`、`~/workspace/custom-connectors/...`）按 GrokBot 的文件布局改。
- `templates/mcp_client.py` 最有价值：Streamable HTTP + session header 管理 + 45 秒超时熔断，改掉凭证注入部分就能用。
- `references/amendments.md` 讲的是 Muse 的部署覆盖机制（系统文件每次部署被替换），GrokBot 如果没有这套部署模型，这份可以直接忽略。
- `templates/connector/CONNECTOR.md` 和 `templates/skill/` 是文档模板，原样可用。

# NOTICE

本技能改编自 obra/superpowers（MIT License），原作者 Jesse Vincent。

Upstream: https://github.com/obra/superpowers
Original author: Jesse Vincent
License: MIT License (see https://github.com/obra/superpowers/blob/main/LICENSE)

改编内容为中英双语重写，方法论内核忠实于原作。

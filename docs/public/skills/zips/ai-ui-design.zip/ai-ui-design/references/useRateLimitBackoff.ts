// 429/503 截断指数退避 + 抖动 + 自动重试上限。改编自 open-claude-ui (MIT)，见 ATTRIBUTION.md
import { useState, useEffect, useCallback, useRef } from "react";

const MIN_DELAY_MS = 5_000, MAX_DELAY_MS = 600_000, MAX_AUTO_RETRIES = 3;

export function useRateLimitBackoff(onAutoRetry: () => void) {
  const [attempt, setAttempt] = useState(0);
  const [retryAt, setRetryAt] = useState<number | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const cb = useRef(onAutoRetry); cb.current = onAutoRetry;

  /** 收到 429/503 时调用；retryAfterSec 取自 Retry-After 头 */
  const trigger = useCallback((retryAfterSec?: number) => {
    setAttempt(prev => {
      const n = prev + 1;
      if (n > MAX_AUTO_RETRIES) { setRetryAt(null); return n; } // 熔断：转为手动重试
      const base = Math.max(retryAfterSec ? retryAfterSec * 1000 : 0, MIN_DELAY_MS);
      const jitter = 0.85 + Math.random() * 0.3;
      const delay = Math.min(base * 2 ** (n - 1) * jitter, MAX_DELAY_MS);
      setRetryAt(Date.now() + delay);
      setSecondsLeft(Math.ceil(delay / 1000));
      return n;
    });
  }, []);

  useEffect(() => {
    if (retryAt == null) return;
    const id = setInterval(() => {
      const left = Math.ceil((retryAt - Date.now()) / 1000);
      if (left <= 0) { clearInterval(id); setRetryAt(null); setSecondsLeft(0); cb.current(); }
      else setSecondsLeft(left);
    }, 1000);
    return () => clearInterval(id);
  }, [retryAt]);

  const reset = useCallback(() => { setAttempt(0); setRetryAt(null); setSecondsLeft(0); }, []);

  return {
    waiting: retryAt != null, secondsLeft, attempt,
    needsManualRetry: attempt > MAX_AUTO_RETRIES, trigger, reset,
  };
}

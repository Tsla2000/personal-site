// CJK 输入法合成守卫。改编自 open-claude-ui (MIT)，见 ATTRIBUTION.md
import { useRef, useCallback } from "react";
import type React from "react";

export function useImeSafeEnter(onSubmit: () => void) {
  const composing = useRef(false);

  const onCompositionStart = useCallback(() => { composing.current = true; }, []);
  // 部分浏览器(Safari)在 compositionend 之后仍会派发 keydown(Enter)，延后一帧清除
  const onCompositionEnd = useCallback(() => {
    setTimeout(() => { composing.current = false; }, 0);
  }, []);

  const onKeyDown = useCallback((e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // 三重判断：自有标记 / 原生 isComposing / 老浏览器 keyCode 229
    if (composing.current || e.nativeEvent.isComposing || e.keyCode === 229) return;
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      onSubmit();
    }
  }, [onSubmit]);

  return { onKeyDown, onCompositionStart, onCompositionEnd };
}
// 用法：<textarea {...useImeSafeEnter(send)} />

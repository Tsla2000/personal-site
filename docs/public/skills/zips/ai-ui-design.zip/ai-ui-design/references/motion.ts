// 通用弹簧预设。改编自 open-claude-ui (MIT)，见 ATTRIBUTION.md
// 阻尼比 ζ = c / (2√(mk))；ζ<1 有超调，ζ≥1 无超调。
import type { Transition } from "framer-motion";

/** 按钮按压、Tab/分段胶囊切换（ζ≈0.61，轻微回弹，快） */
export const SPRING_PRESS: Transition = { type: "spring", stiffness: 600, damping: 30, mass: 1 };
/** 卡片展开、Popover、消息入场（ζ≈0.78，几乎无超调） */
export const SPRING_REVEAL: Transition = { type: "spring", stiffness: 320, damping: 28, mass: 1 };
/** 成功勾选、点赞等情绪反馈（ζ≈0.46，明显回弹，慎用） */
export const SPRING_DELIGHT: Transition = { type: "spring", stiffness: 380, damping: 18, mass: 1 };
/** 拖拽吸附、侧栏/分栏归位（过阻尼，零超调） */
export const SPRING_SNAP: Transition = { type: "spring", stiffness: 1200, damping: 80, mass: 0.1 };

export const dampingRatio = (k: number, c: number, m: number) => c / (2 * Math.sqrt(m * k));

/** 归一化位移 x(t)，用于自测/画曲线 */
export function springAt(k: number, c: number, m: number, t: number): number {
  const w0 = Math.sqrt(k / m), z = dampingRatio(k, c, m);
  if (z < 1) {
    const wd = w0 * Math.sqrt(1 - z * z);
    return 1 - Math.exp(-z * w0 * t) * (Math.cos(wd * t) + (z / Math.sqrt(1 - z * z)) * Math.sin(wd * t));
  }
  if (Math.abs(z - 1) < 1e-4) return 1 - Math.exp(-w0 * t) * (1 + w0 * t);
  const s1 = -w0 * (z - Math.sqrt(z * z - 1)), s2 = -w0 * (z + Math.sqrt(z * z - 1));
  return 1 - (s2 * Math.exp(s1 * t) - s1 * Math.exp(s2 * t)) / (s2 - s1);
}

// 模型生成 HTML/代码的隔离预览。改编自 open-claude-ui (MIT)，见 ATTRIBUTION.md
import React, { useEffect, useRef } from "react";

export function SandboxedPreview({ html, onMessage, title = "预览" }: {
  html: string; title?: string; onMessage?: (data: unknown) => void;
}) {
  const ref = useRef<HTMLIFrameElement>(null);
  useEffect(() => {
    const handler = (e: MessageEvent) => {
      // srcdoc + 无 allow-same-origin => origin 为 "null"；必须同时校验 source
      if (e.source !== ref.current?.contentWindow) return;
      if (e.origin !== "null") return;
      onMessage?.(e.data); // 调用方仍需对 data 做 schema 校验
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, [onMessage]);

  return (
    <iframe ref={ref} title={title} srcDoc={html}
      // 绝不同时给 allow-scripts + allow-same-origin
      sandbox="allow-scripts"
      referrerPolicy="no-referrer"
      allow=""
      className="h-full w-full border-0 bg-white" />
  );
}

/** 拖拽分栏经过 iframe 时，给预览加一层透明遮罩，防止 iframe 吞掉 pointer 事件 */
export const DragShield = ({ active }: { active: boolean }) =>
  active ? <div aria-hidden className="absolute inset-0 z-10" /> : null;

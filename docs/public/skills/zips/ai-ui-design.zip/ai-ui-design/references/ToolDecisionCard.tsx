// 工具调用三态确认卡（受控组件，状态由调用方/运行时驱动）。改编自 open-claude-ui (MIT)，见 ATTRIBUTION.md
import React, { useEffect, useRef } from "react";

export type ToolStatus = "pending_approval" | "running" | "success" | "error" | "denied";
export type Verdict = "allow_once" | "always_allow" | "deny";

export interface ToolCall {
  id: string;
  toolName: string;
  source?: string;              // 如 "mcp://filesystem"
  risk?: "read" | "write" | "destructive";
  input: Record<string, unknown>;
  output?: string;
  error?: string;
  durationMs?: number;
}

export function ToolDecisionCard({ call, status, onVerdict }: {
  call: ToolCall; status: ToolStatus; onVerdict: (v: Verdict) => void;
}) {
  const firstBtn = useRef<HTMLButtonElement>(null);
  useEffect(() => { if (status === "pending_approval") firstBtn.current?.focus(); }, [status]);
  const destructive = call.risk === "destructive";

  return (
    <section role="group" aria-label={`工具调用：${call.toolName}`} aria-busy={status === "running"}
      className="rounded-[var(--radius-btn)] border border-[var(--border-card)] bg-[var(--surface-1)] p-3 text-[var(--text-sm)]">
      <header className="flex items-center gap-2">
        <span className="font-[var(--font-mono)] text-[var(--text-primary)]">{call.toolName}</span>
        {call.source && <span className="text-[var(--text-tertiary)]">{call.source}</span>}
        <span aria-live="polite" className="ml-auto text-[var(--text-secondary)]">{LABEL[status]}</span>
      </header>

      {/* 参数永远完整可见、只读，禁止只展示摘要 */}
      <pre className="mt-2 max-h-48 overflow-auto rounded-[var(--radius-chip)] bg-[var(--surface-2)] p-2 font-[var(--font-mono)] text-[var(--text-xs)]">
        {JSON.stringify(call.input, null, 2)}
      </pre>

      {status === "pending_approval" && (
        <div className="mt-3 flex flex-wrap gap-2">
          <button ref={firstBtn} onClick={() => onVerdict("allow_once")}
            className="rounded-[var(--radius-btn)] bg-[var(--brand-500)] px-3 py-1.5 text-[var(--brand-on)]">允许一次</button>
          {/* 破坏性操作不提供“始终允许” */}
          {!destructive && (
            <button onClick={() => onVerdict("always_allow")}
              className="rounded-[var(--radius-btn)] bg-[var(--surface-3)] px-3 py-1.5">始终允许此工具</button>
          )}
          <button onClick={() => onVerdict("deny")}
            className="rounded-[var(--radius-btn)] px-3 py-1.5 text-[var(--danger)]">拒绝</button>
        </div>
      )}
      {status === "success" && call.output && (
        <details className="mt-2"><summary>查看结果{call.durationMs != null && `（${call.durationMs}ms）`}</summary>
          <pre className="mt-1 whitespace-pre-wrap text-[var(--text-xs)]">{call.output}</pre></details>
      )}
      {status === "error" && <p role="alert" className="mt-2 text-[var(--danger)]">{call.error ?? "执行失败"}</p>}
    </section>
  );
}

const LABEL: Record<ToolStatus, string> = {
  pending_approval: "等待确认", running: "执行中…", success: "已完成", error: "失败", denied: "已拒绝",
};

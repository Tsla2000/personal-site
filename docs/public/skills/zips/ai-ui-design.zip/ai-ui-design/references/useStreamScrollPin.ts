// 流式输出滚动图钉。改编自 open-claude-ui (MIT)，见 ATTRIBUTION.md
import { useEffect, useRef, useState, useCallback } from "react";

const PIN_TOLERANCE_PX = 40;   // 距底部 ≤40px 视为“贴底”
const JUMP_BUTTON_PX = 120;    // 离底部 >120px 显示“回到最新”
const USER_COOLDOWN_MS = 150;  // 用户刚滚动/触摸后不抢视口

export function useStreamScrollPin(contentVersion: unknown) {
  const ref = useRef<HTMLDivElement>(null);
  const [pinned, setPinned] = useState(true);
  const [showJump, setShowJump] = useState(false);
  const lastUserInput = useRef(0);
  const programmatic = useRef(false);

  const markUserInput = useCallback(() => { lastUserInput.current = performance.now(); }, []);

  const onScroll = useCallback(() => {
    if (programmatic.current) { programmatic.current = false; return; }
    const el = ref.current; if (!el) return;
    const d = el.scrollHeight - el.scrollTop - el.clientHeight;
    setPinned(d <= PIN_TOLERANCE_PX);
    setShowJump(d > JUMP_BUTTON_PX);
  }, []);

  const scrollToBottom = useCallback((smooth = false) => {
    const el = ref.current; if (!el) return;
    programmatic.current = true;
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? "smooth" : "auto" });
    setPinned(true); setShowJump(false);
  }, []);

  useEffect(() => {
    if (performance.now() - lastUserInput.current <= USER_COOLDOWN_MS) return;
    if (pinned) scrollToBottom(false); // 流式期间用 auto，smooth 会追不上 token
  }, [contentVersion, pinned, scrollToBottom]);

  // 绑定：<div ref={ref} onScroll={onScroll} onWheel={markUserInput} onTouchMove={markUserInput} onKeyDown={markUserInput}>
  return { ref, pinned, showJump, onScroll, markUserInput, scrollToBottom };
}

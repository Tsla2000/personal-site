# 来源与许可

本目录代码片段改编自开源项目 open-claude-ui（https://github.com/Caho1/open-claude-ui，MIT License，Copyright (c) 2026 Caho1），原许可证全文见 `LICENSE-open-claude-ui.txt`。

改编说明：已去除原品牌名称、配色与逆向溯源注释，重命名为通用 API，修正/简化部分逻辑。仅保留通用交互模式。再分发时请保留本文件与许可证副本。
